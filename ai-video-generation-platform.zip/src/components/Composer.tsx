"use client";

import {
  ArrowRight,
  ArrowUpRight,
  Globe,
  Link2,
  Loader2,
  Play,
  Plus,
  Square,
  Volume2,
  X,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import { AspectGlyph, AudioMeter } from "@/components/BrandMark";
import {
  ASPECT_ORDER,
  ASPECTS,
  RESOLUTION_ORDER,
  RESOLUTIONS,
  TONES,
  type AspectRatio,
  type ResearchDossier,
  type Resolution,
  type Tone,
} from "@/lib/types";
import { VOICES } from "@/lib/voices";

const SAMPLE_BRIEFS: {
  code: string;
  label: string;
  prompt: string;
  urls?: string[];
  aspect: AspectRatio;
  tone: Tone;
  duration: number;
}[] = [
  {
    code: "01",
    label: "Research topic",
    prompt: "How solid-state batteries are changing electric vehicle range and charging speed",
    aspect: "16:9",
    tone: "professional",
    duration: 30,
  },
  {
    code: "02",
    label: "Extract website URL",
    prompt: "Create a cinematic breakdown of specialty coffee roasting chemistry and temperature stages",
    urls: ["https://en.wikipedia.org/wiki/Coffee_roasting"],
    aspect: "16:9",
    tone: "cinematic",
    duration: 30,
  },
  {
    code: "03",
    label: "Vertical social cut",
    prompt: "Why high-speed rail corridors are reshaping European city travel",
    aspect: "9:16",
    tone: "energetic",
    duration: 30,
  },
  {
    code: "04",
    label: "Tech explainer",
    prompt: "How Node.js non-blocking event loop architecture handles concurrent network traffic",
    urls: ["https://nodejs.org/en/learn/asynchronous-work/event-loop-timers-and-nexttick"],
    aspect: "16:9",
    tone: "minimal",
    duration: 45,
  },
];

function computeRaster(resolution: Resolution, aspect: AspectRatio): string {
  const base = RESOLUTIONS[resolution];
  const ratio = ASPECTS[aspect].ratio;
  const short = Math.min(base.width, base.height);
  let width = short;
  let height = short;
  if (ratio >= 1) {
    height = short;
    width = Math.round((short * ratio) / 2) * 2;
  } else {
    width = short;
    height = Math.round(short / ratio / 2) * 2;
  }
  return `${width}×${height}`;
}

export default function Composer() {
  const router = useRouter();
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const [prompt, setPrompt] = useState("");
  const [researchMode, setResearchMode] = useState(true);
  const [showUrlTray, setShowUrlTray] = useState(false);
  const [urlDraft, setUrlDraft] = useState("");
  const [sourceUrls, setSourceUrls] = useState<string[]>([]);
  const [previewDossier, setPreviewDossier] = useState<ResearchDossier | null>(null);
  const [researching, setResearching] = useState(false);

  const [resolution, setResolution] = useState<Resolution>("1080p");
  const [aspect, setAspect] = useState<AspectRatio>("16:9");
  const [tone, setTone] = useState<Tone>("cinematic");
  const [voice, setVoice] = useState<string>("ava");
  const [duration, setDuration] = useState<number>(30);
  const [loading, setLoading] = useState(false);
  const [auditioning, setAuditioning] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    function handleBrief(event: Event) {
      const detail = (
        event as CustomEvent<{ prompt?: string; aspect?: AspectRatio; urls?: string[] }>
      ).detail;
      if (!detail?.prompt) return;
      setPrompt(detail.prompt);
      if (detail.aspect) setAspect(detail.aspect);
      if (detail.urls?.length) {
        setSourceUrls(detail.urls);
        setShowUrlTray(true);
      }
      setPreviewDossier(null);
      textareaRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      setTimeout(() => textareaRef.current?.focus(), 250);
    }
    window.addEventListener("cutline:use-brief", handleBrief);
    return () => window.removeEventListener("cutline:use-brief", handleBrief);
  }, []);

  const raster = useMemo(() => computeRaster(resolution, aspect), [resolution, aspect]);
  const estimatedScenes = useMemo(
    () => Math.max(3, Math.min(12, Math.round(duration / 9))),
    [duration],
  );
  const selectedVoice = useMemo(
    () => VOICES.find((item) => item.id === voice) ?? VOICES[0],
    [voice],
  );

  function addSourceUrl() {
    const raw = urlDraft.trim();
    if (!raw) return;
    const normalized = /^https?:\/\//i.test(raw) ? raw : `https://${raw}`;
    try {
      const parsed = new URL(normalized);
      const clean = parsed.toString();
      if (!sourceUrls.includes(clean)) {
        setSourceUrls((curr) => [...curr, clean].slice(0, 5));
        setPreviewDossier(null);
      }
      setUrlDraft("");
      setResearchMode(true);
    } catch {
      setError("Enter a valid website URL (e.g. https://example.com/article)");
    }
  }

  function removeSourceUrl(target: string) {
    setSourceUrls((curr) => curr.filter((u) => u !== target));
    setPreviewDossier(null);
  }

  async function runLiveResearchPreview() {
    const pendingUrl = urlDraft.trim();
    let urlsToUse = [...sourceUrls];
    if (pendingUrl) {
      const normalized = /^https?:\/\//i.test(pendingUrl)
        ? pendingUrl
        : `https://${pendingUrl}`;
      try {
        const clean = new URL(normalized).toString();
        if (!urlsToUse.includes(clean)) {
          urlsToUse = [...urlsToUse, clean].slice(0, 5);
          setSourceUrls(urlsToUse);
        }
        setUrlDraft("");
      } catch {
        setError("Enter a valid website URL before inspecting.");
        return;
      }
    }

    if (!prompt.trim() && urlsToUse.length === 0) return;

    setResearching(true);
    setError(null);
    try {
      const response = await fetch("/api/research", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          prompt: prompt.trim(),
          urls: urlsToUse,
          maxSources: 5,
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Research crawl failed");
      setPreviewDossier(data.dossier as ResearchDossier);
      setResearchMode(true);
    } catch (cause) {
      setError(
        cause instanceof Error ? cause.message : "Could not reach target websites.",
      );
    } finally {
      setResearching(false);
    }
  }

  async function toggleAudition() {
    if (auditioning && audioRef.current) {
      audioRef.current.pause();
      setAuditioning(false);
      return;
    }
    try {
      setAuditioning(true);
      const sampleText =
        previewDossier?.keyFacts[0]?.text ??
        (prompt.trim().length > 16
          ? prompt.trim().slice(0, 200)
          : selectedVoice.previewText);
      const response = await fetch("/api/tts/preview", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ voiceId: selectedVoice.id, text: sampleText }),
      });
      if (!response.ok) throw new Error("Voice preview unavailable");
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      if (!audioRef.current) audioRef.current = new Audio();
      audioRef.current.src = url;
      audioRef.current.onended = () => setAuditioning(false);
      audioRef.current.onerror = () => setAuditioning(false);
      await audioRef.current.play();
    } catch {
      setAuditioning(false);
    }
  }

  async function submitBrief() {
    const canSubmit = Boolean(prompt.trim() || sourceUrls.length > 0);
    if (!canSubmit || loading) return;
    setLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/projects", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          prompt: prompt.trim() || sourceUrls.join(" "),
          resolution,
          aspect,
          tone,
          voice,
          duration,
          researchMode,
          sourceUrls,
          preloadedDossier: previewDossier,
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Failed to draft sequence");
      router.push(`/studio/${data.project.id}`);
    } catch (cause) {
      setError(
        cause instanceof Error ? cause.message : "Could not initialize sequence.",
      );
      setLoading(false);
    }
  }

  const canDraft = Boolean(prompt.trim() || sourceUrls.length > 0);

  return (
    <div className="console-surface rounded-[4px]">
      {/* Top slate bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line bg-inset px-4 py-2.5">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-amber-cue" />
            <span className="font-tech text-[11px] font-medium uppercase tracking-[0.14em] text-paper">
              Sequence Slate
            </span>
          </div>

          <button
            type="button"
            onClick={() => setResearchMode((v) => !v)}
            className={`inline-flex items-center gap-1.5 rounded-[2px] border px-2 py-0.5 font-tech text-[10px] uppercase tracking-[0.1em] transition-colors ${
              researchMode
                ? "border-nominal/45 bg-nominal/10 text-nominal"
                : "border-line bg-canvas text-ash hover:text-stone-ink"
            }`}
          >
            <Globe className="h-3 w-3" />
            <span>Web Research: {researchMode ? "Live" : "Off"}</span>
          </button>
        </div>

        <div className="font-tech flex flex-wrap items-center gap-3 text-[11px] text-stone-ink">
          <span>{raster}px</span>
          <span className="text-line-strong">/</span>
          <span>30.00 fps</span>
          <span className="text-line-strong">/</span>
          <span>~{estimatedScenes} cues</span>
        </div>
      </div>

      {/* Prompt brief input */}
      <div className="p-4 sm:p-5">
        <div className="mb-2 flex flex-wrap items-center justify-between gap-2 text-xs font-medium text-stone-ink">
          <label htmlFor="sequence-brief">
            Topic, production brief, or paste any website URL
          </label>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setShowUrlTray((v) => !v)}
              className="inline-flex items-center gap-1 font-tech text-[11px] text-amber-cue transition-colors hover:text-amber-hover"
            >
              <Link2 className="h-3 w-3" />
              <span>
                {sourceUrls.length > 0
                  ? `Source URLs (${sourceUrls.length})`
                  : showUrlTray
                    ? "Hide URL ingest"
                    : "+ Attach website URLs"}
              </span>
            </button>
          </div>
        </div>

        <textarea
          id="sequence-brief"
          ref={textareaRef}
          value={prompt}
          onChange={(event) => {
            setPrompt(event.target.value);
            if (previewDossier) setPreviewDossier(null);
          }}
          onKeyDown={(event) => {
            if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
              event.preventDefault();
              void submitBrief();
            }
          }}
          rows={3}
          placeholder="Enter any topic to research on the live web, or paste an article / documentation / product URL — Cutline visits the pages, extracts key facts, and cuts a narrated video…"
          className="w-full resize-none rounded-[3px] border border-line bg-canvas px-3.5 py-3 text-[15px] leading-relaxed text-paper outline-none transition-colors placeholder:text-ash focus:border-amber-cue"
        />

        {/* Direct Website URL Ingest Tray */}
        {showUrlTray || sourceUrls.length > 0 ? (
          <div className="mt-2.5 rounded-[3px] border border-line bg-inset p-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="font-tech text-[10px] uppercase tracking-[0.14em] text-stone-ink">
                Direct Website Crawl List (Readability + Metadata Extractor)
              </span>
              <span className="font-tech text-[10px] text-ash">
                Up to 5 URLs · visited server-side
              </span>
            </div>

            <div className="mt-2 flex flex-col gap-2 sm:flex-row">
              <input
                type="url"
                value={urlDraft}
                onChange={(event) => setUrlDraft(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter") {
                    event.preventDefault();
                    addSourceUrl();
                  }
                }}
                placeholder="https://en.wikipedia.org/wiki/... or any article / company URL"
                className="min-w-0 flex-1 rounded-[3px] border border-line bg-canvas px-3 py-1.5 font-tech text-xs text-paper outline-none transition-colors placeholder:text-ash focus:border-amber-cue"
              />
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={addSourceUrl}
                  disabled={!urlDraft.trim()}
                  className="inline-flex items-center gap-1 rounded-[3px] border border-line bg-panel px-2.5 py-1.5 font-tech text-[11px] text-paper transition-colors hover:border-line-strong disabled:opacity-40"
                >
                  <Plus className="h-3 w-3" />
                  <span>Add URL</span>
                </button>
                <button
                  type="button"
                  onClick={() => void runLiveResearchPreview()}
                  disabled={researching || (!prompt.trim() && !urlDraft.trim() && sourceUrls.length === 0)}
                  className="inline-flex items-center gap-1.5 rounded-[3px] border border-amber-cue/45 bg-amber-cue/10 px-3 py-1.5 font-tech text-[11px] text-amber-cue transition-colors hover:bg-amber-cue/20 disabled:opacity-40"
                >
                  {researching ? (
                    <>
                      <Loader2 className="h-3 w-3 animate-spin" />
                      <span>Visiting…</span>
                    </>
                  ) : (
                    <>
                      <Globe className="h-3 w-3" />
                      <span>Inspect Sources</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {sourceUrls.length > 0 ? (
              <div className="mt-2.5 flex flex-wrap gap-1.5">
                {sourceUrls.map((url) => {
                  let label = url;
                  try {
                    const u = new URL(url);
                    label = `${u.hostname.replace(/^www\./, "")}${
                      u.pathname.length > 1 ? u.pathname.slice(0, 26) : ""
                    }`;
                  } catch {
                    // keep raw
                  }
                  return (
                    <span
                      key={url}
                      className="inline-flex items-center gap-1.5 rounded-[2px] border border-line-strong bg-canvas px-2 py-0.5 font-tech text-[11px] text-paper"
                    >
                      <Link2 className="h-2.5 w-2.5 text-amber-cue" />
                      <span className="max-w-[230px] truncate">{label}</span>
                      <button
                        type="button"
                        onClick={() => removeSourceUrl(url)}
                        aria-label={`Remove ${url}`}
                        className="text-ash hover:text-tally"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </span>
                  );
                })}
              </div>
            ) : null}
          </div>
        ) : null}

        {/* Sample preset + Live Inspect trigger strip */}
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-b border-line pb-3.5 text-xs">
          <div className="flex flex-wrap items-center gap-x-3.5 gap-y-1.5">
            <span className="font-tech text-[10px] uppercase tracking-[0.14em] text-ash">
              Load brief:
            </span>
            {SAMPLE_BRIEFS.map((sample) => (
              <button
                key={sample.code}
                type="button"
                onClick={() => {
                  setPrompt(sample.prompt);
                  setAspect(sample.aspect);
                  setTone(sample.tone);
                  setDuration(sample.duration);
                  setSourceUrls(sample.urls ?? []);
                  setShowUrlTray(Boolean(sample.urls?.length));
                  setResearchMode(true);
                  setPreviewDossier(null);
                }}
                className="group inline-flex items-center gap-1 text-left text-stone-ink transition-colors hover:text-paper"
              >
                <span className="font-tech text-[10px] text-amber-cue/80 group-hover:text-amber-cue">
                  [{sample.code}]
                </span>
                <span className="underline decoration-line-strong underline-offset-4 group-hover:decoration-amber-cue">
                  {sample.label}
                </span>
              </button>
            ))}
          </div>

          {!showUrlTray && canDraft ? (
            <button
              type="button"
              onClick={() => void runLiveResearchPreview()}
              disabled={researching}
              className="inline-flex items-center gap-1.5 font-tech text-[11px] text-stone-ink transition-colors hover:text-amber-cue disabled:opacity-50"
            >
              {researching ? (
                <>
                  <Loader2 className="h-3 w-3 animate-spin text-amber-cue" />
                  <span>Crawling live pages…</span>
                </>
              ) : (
                <>
                  <Globe className="h-3 w-3 text-amber-cue" />
                  <span>Preview web research</span>
                </>
              )}
            </button>
          ) : null}
        </div>

        {/* Live Extracted Dossier Preview (when user inspects sources before drafting) */}
        {previewDossier && previewDossier.sources.length > 0 ? (
          <div className="mt-3 rounded-[3px] border border-nominal/35 bg-inset p-3">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line pb-2 font-tech text-[10px]">
              <span className="uppercase tracking-[0.12em] text-nominal">
                Dossier Ready // {previewDossier.sources.length} Website(s) Extracted ·{" "}
                {previewDossier.keyFacts.length} Grounded Facts
              </span>
              <button
                type="button"
                onClick={() => setPreviewDossier(null)}
                className="text-ash hover:text-paper"
              >
                Clear
              </button>
            </div>
            <div className="mt-2 grid gap-1.5 sm:grid-cols-2">
              {previewDossier.sources.slice(0, 4).map((src) => (
                <a
                  key={src.id}
                  href={src.url}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-start justify-between gap-2 rounded-[2px] border border-line bg-canvas px-2.5 py-1.5 text-left transition-colors hover:border-line-strong"
                >
                  <div className="min-w-0">
                    <p className="truncate text-[11px] font-medium text-paper">
                      {src.title}
                    </p>
                    <p className="font-tech text-[10px] text-ash">
                      {src.domain} · {src.wordCount}w · {src.facts.length} facts
                    </p>
                  </div>
                  <ArrowUpRight className="mt-0.5 h-3 w-3 shrink-0 text-stone-ink" />
                </a>
              ))}
            </div>
            {previewDossier.keyFacts[0] ? (
              <p className="mt-2 border-l-2 border-amber-cue pl-2.5 text-xs leading-relaxed text-stone-ink">
                Lead finding: “{previewDossier.keyFacts[0].text}”
              </p>
            ) : null}
          </div>
        ) : null}

        {/* Tactile hardware spec controls */}
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-12">
          {/* Deliverable resolution */}
          <div className="lg:col-span-4">
            <span className="font-tech mb-1.5 block text-[10px] uppercase tracking-[0.14em] text-ash">
              Master Raster
            </span>
            <div className="grid grid-cols-3 rounded-[3px] border border-line bg-canvas p-0.5">
              {RESOLUTION_ORDER.map((opt) => {
                const active = resolution === opt;
                return (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setResolution(opt)}
                    className={`rounded-[2px] px-2 py-1.5 text-center transition-colors ${
                      active
                        ? "bg-elevated text-paper shadow-[inset_0_0_0_1px_#3a3832]"
                        : "text-stone-ink hover:text-paper"
                    }`}
                  >
                    <span className="font-tech block text-xs font-medium">{opt}</span>
                    <span className="block text-[10px] text-ash">
                      {RESOLUTIONS[opt].role}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Aspect Gate */}
          <div className="lg:col-span-4">
            <span className="font-tech mb-1.5 block text-[10px] uppercase tracking-[0.14em] text-ash">
              Frame Gate
            </span>
            <div className="grid grid-cols-3 rounded-[3px] border border-line bg-canvas p-0.5">
              {ASPECT_ORDER.map((opt) => {
                const active = aspect === opt;
                return (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setAspect(opt)}
                    className={`flex flex-col items-center justify-center gap-0.5 rounded-[2px] px-2 py-1.5 transition-colors ${
                      active
                        ? "bg-elevated text-paper shadow-[inset_0_0_0_1px_#3a3832]"
                        : "text-stone-ink hover:text-paper"
                    }`}
                  >
                    <span className="inline-flex items-center gap-1 font-tech text-xs font-medium">
                      <AspectGlyph aspect={opt} className="h-3 w-3" />
                      {opt}
                    </span>
                    <span className="text-[10px] text-ash">
                      {opt === "16:9" ? "Wide" : opt === "9:16" ? "Vertical" : "Square"}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Runtime */}
          <div className="lg:col-span-4">
            <span className="font-tech mb-1.5 block text-[10px] uppercase tracking-[0.14em] text-ash">
              Target Runtime
            </span>
            <div className="grid grid-cols-5 rounded-[3px] border border-line bg-canvas p-0.5">
              {[15, 30, 45, 60, 90].map((sec) => {
                const active = duration === sec;
                return (
                  <button
                    key={sec}
                    type="button"
                    onClick={() => setDuration(sec)}
                    className={`flex flex-col items-center justify-center rounded-[2px] py-1.5 transition-colors ${
                      active
                        ? "bg-elevated text-paper shadow-[inset_0_0_0_1px_#3a3832]"
                        : "text-stone-ink hover:text-paper"
                    }`}
                  >
                    <span className="font-tech text-xs font-medium">{sec}s</span>
                    <span className="text-[10px] text-ash">
                      {Math.max(3, Math.round(sec / 9))}sc
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Voice booth + Editorial Tone + Submit row */}
        <div className="mt-3 grid gap-3 border-t border-line pt-3.5 sm:grid-cols-12 sm:items-end">
          <div className="sm:col-span-5">
            <span className="font-tech mb-1.5 flex items-center justify-between text-[10px] uppercase tracking-[0.14em] text-ash">
              <span>Neural Narrator (24kHz)</span>
              <span>{selectedVoice.accent}</span>
            </span>
            <div className="flex items-stretch gap-1.5">
              <select
                aria-label="Narrator voice"
                value={voice}
                onChange={(event) => {
                  if (auditioning && audioRef.current) {
                    audioRef.current.pause();
                    setAuditioning(false);
                  }
                  setVoice(event.target.value);
                }}
                className="min-w-0 flex-1 rounded-[3px] border border-line bg-canvas px-3 py-2 text-xs font-medium text-paper outline-none transition-colors focus:border-amber-cue"
              >
                {VOICES.map((item) => (
                  <option key={item.id} value={item.id} className="bg-panel text-paper">
                    {item.name} — {item.style} ({item.accent})
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={() => void toggleAudition()}
                title="Audition narrator voice"
                className="inline-flex items-center gap-1.5 rounded-[3px] border border-line bg-inset px-2.5 py-2 font-tech text-[11px] text-stone-ink transition-colors hover:border-line-strong hover:text-paper"
              >
                {auditioning ? (
                  <>
                    <AudioMeter active />
                    <Square className="h-3 w-3 fill-current text-amber-cue" />
                  </>
                ) : (
                  <>
                    <Volume2 className="h-3.5 w-3.5 text-amber-cue" />
                    <span>Test</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="sm:col-span-3">
            <label className="block">
              <span className="font-tech mb-1.5 block text-[10px] uppercase tracking-[0.14em] text-ash">
                Editorial Pace
              </span>
              <select
                value={tone}
                onChange={(event) => setTone(event.target.value as Tone)}
                className="w-full rounded-[3px] border border-line bg-canvas px-3 py-2 text-xs font-medium capitalize text-paper outline-none transition-colors focus:border-amber-cue"
              >
                {TONES.map((opt) => (
                  <option key={opt} value={opt} className="bg-panel capitalize text-paper">
                    {opt}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <div className="sm:col-span-4">
            <button
              type="button"
              onClick={() => void submitBrief()}
              disabled={loading || !canDraft}
              className="inline-flex w-full items-center justify-center gap-2 rounded-[3px] bg-amber-cue px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.08em] text-[#14110A] transition-colors hover:bg-amber-hover disabled:cursor-not-allowed disabled:bg-elevated disabled:text-ash"
            >
              {loading ? (
                <>
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  <span>
                    {researchMode && !previewDossier
                      ? "Researching & Drafting…"
                      : "Building Rundown…"}
                  </span>
                </>
              ) : (
                <>
                  <Play className="h-3 w-3 fill-current" />
                  <span>{researchMode ? "Research & Draft Cut" : "Draft Cut in Studio"}</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </>
              )}
            </button>
          </div>
        </div>

        {error ? (
          <div className="mt-3 rounded-[3px] border border-tally/50 bg-tally/10 px-3 py-2 font-tech text-xs text-[#f4b4a8]">
            ERR // {error}
          </div>
        ) : null}
      </div>
    </div>
  );
}
