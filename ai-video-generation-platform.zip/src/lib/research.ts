import { createHash } from "node:crypto";
import { Readability } from "@mozilla/readability";
import { parseHTML } from "linkedom";
import type {
  ResearchDossier,
  ResearchFact,
  ResearchLogEntry,
  ResearchSource,
  ResearchVia,
} from "./types";

const BROWSER_UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

const BLOCKED_DOMAINS = new Set([
  "merriam-webster.com",
  "dictionary.cambridge.org",
  "dictionary.com",
  "thesaurus.com",
  "wiktionary.org",
  "collinsdictionary.com",
  "vocabulary.com",
  "wordreference.com",
  "urbandictionary.com",
  "facebook.com",
  "instagram.com",
  "tiktok.com",
  "pinterest.com",
  "linkedin.com",
  "x.com",
  "twitter.com",
  "youtube.com",
  "youtu.be",
  "bing.com",
  "google.com",
  "duckduckgo.com",
  "jstor.org",
  "doi.org",
  "researchgate.net",
  "academia.edu",
]);

const BOT_CHALLENGE_TITLE_RE =
  /^(client challenge|just a moment|attention required|access denied|403 forbidden|robot or human|security check|pardon our interruption|verify you are human|page not found|404)/i;

const CHROME_HEADING_RE =
  /\b(sidebar|navigation|main menu|footer|comments?|leave a reply|related (posts|articles|stories)|more for you|more from|you may also like|recommended|read next|keep reading|top stories|newsletter|subscribe|cookie|advertisement|sponsored|most popular|trending|follow us|share this|search|table of contents|about the author)\b/i;

const BOILERPLATE_PATTERNS = [
  /cookie/i,
  /privacy policy/i,
  /terms of service/i,
  /all rights reserved/i,
  /sign up for our newsletter/i,
  /subscribe to continue/i,
  /enable javascript/i,
  /javascript is disabled/i,
  /verify you are human/i,
  /browser extension|browser settings|network issues/i,
  /ad[- ]?blocker/i,
  /cloudflare/i,
  /client challenge/i,
  /pardon our interruption/i,
  /advertisement/i,
  /click here to/i,
  /read more:/i,
  /share this article/i,
  /follow us on/i,
  /skip to (main )?content/i,
];

type CandidateUrl = {
  url: string;
  title?: string;
  snippet?: string;
  via: ResearchVia;
  publishedAt?: string | null;
  priority: number;
};

function shortId(input: string): string {
  return createHash("sha1").update(input).digest("hex").slice(0, 10);
}

function getDomain(rawUrl: string): string {
  try {
    return new URL(rawUrl).hostname.replace(/^www\./i, "").toLowerCase();
  } catch {
    return "";
  }
}

/**
 * Guard outbound server fetches against SSRF (private IPs, loopback, link-local).
 */
export function isSafeExternalUrl(rawUrl: string): boolean {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return false;
    const host = parsed.hostname.toLowerCase();
    if (
      host === "localhost" ||
      host === "0.0.0.0" ||
      host === "[::1]" ||
      host === "::1" ||
      host.endsWith(".local") ||
      host.endsWith(".internal") ||
      host.endsWith(".localhost")
    ) {
      return false;
    }
    if (/^127\./.test(host) || /^10\./.test(host) || /^192\.168\./.test(host) || /^169\.254\./.test(host)) {
      return false;
    }
    const m172 = /^172\.(\d+)\./.exec(host);
    if (m172) {
      const second = Number(m172[1]);
      if (second >= 16 && second <= 31) return false;
    }
    return Boolean(host.includes("."));
  } catch {
    return false;
  }
}

export function extractUrlsFromText(text: string): string[] {
  const matches = text.match(/https?:\/\/[^\s<>"'`]+/gi) ?? [];
  const seen = new Set<string>();
  const out: string[] = [];
  for (const raw of matches) {
    const cleaned = raw.replace(/[.,;:!?)\]}]+$/, "");
    if (!isSafeExternalUrl(cleaned)) continue;
    const normalized = normalizeUrl(cleaned);
    if (!seen.has(normalized)) {
      seen.add(normalized);
      out.push(normalized);
    }
  }
  return out;
}

function normalizeUrl(rawUrl: string): string {
  try {
    const u = new URL(rawUrl);
    u.hash = "";
    for (const param of [
      "utm_source",
      "utm_medium",
      "utm_campaign",
      "utm_term",
      "utm_content",
      "fbclid",
      "gclid",
      "ref",
    ]) {
      u.searchParams.delete(param);
    }
    return u.toString();
  } catch {
    return rawUrl;
  }
}

export function stripUrlsAndFraming(prompt: string): string {
  let q = prompt
    .replace(/https?:\/\/[^\s<>"'`]+/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
  q = q.replace(
    /^(?:please\s+)?(?:can you\s+)?(?:research(?:\s+and)?\s+)?(?:make|create|generate|write|build|produce|cut|draft)\s+(?:me\s+)?(?:a|an|the)?\s*(?:\d+\s*[- ]?(?:second|sec|s|minute|min)s?\s+)?(?:[\w'-]+\s+){0,3}?(?:video|clip|reel|ad|explainer|film|promo|documentary|rundown|piece)\s+(?:about|on|for|explaining|covering|from|using)\s+/i,
    "",
  );
  q = q.replace(
    /^(?:a|an|the)?\s*\d+\s*[- ]?(?:second|sec|s|minute|min)s?\s+(?:[\w'-]+\s+){0,3}?(?:video|clip|reel|explainer|film|promo|documentary)\s+(?:about|on|for|covering)\s+/i,
    "",
  );
  q = q.replace(/[.!?]+$/, "").trim();
  return q;
}

function isBlockedDomain(url: string): boolean {
  const domain = getDomain(url);
  if (!domain) return true;
  if (BLOCKED_DOMAINS.has(domain)) return true;
  for (const blocked of BLOCKED_DOMAINS) {
    if (domain.endsWith(`.${blocked}`)) return true;
  }
  return false;
}

function tokenizeQuery(query: string): string[] {
  const stop = new Set([
    "the",
    "and",
    "for",
    "with",
    "that",
    "this",
    "from",
    "about",
    "into",
    "how",
    "why",
    "what",
    "when",
    "where",
    "who",
    "are",
    "was",
    "were",
    "will",
    "have",
    "has",
    "video",
    "short",
    "explain",
    "explainer",
  ]);
  return query
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .split(/\s+/)
    .filter((token) => token.length > 2 && !stop.has(token));
}

function decodeXmlEntities(value: string): string {
  return value
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, num) => String.fromCharCode(Number(num)))
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function parseRssItems(xml: string): {
  title: string;
  link: string;
  description: string;
  pubDate: string | null;
}[] {
  const items: {
    title: string;
    link: string;
    description: string;
    pubDate: string | null;
  }[] = [];
  const itemRegex = /<item\b[^>]*>([\s\S]*?)<\/item>/gi;
  let match: RegExpExecArray | null;
  while ((match = itemRegex.exec(xml)) !== null) {
    const block = match[1];
    const titleMatch = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(block);
    const linkMatch = /<link[^>]*>([\s\S]*?)<\/link>/i.exec(block);
    const descMatch = /<description[^>]*>([\s\S]*?)<\/description>/i.exec(block);
    const dateMatch = /<pubDate[^>]*>([\s\S]*?)<\/pubDate>/i.exec(block);
    const rawLink = decodeXmlEntities(linkMatch?.[1] ?? "");
    if (!rawLink) continue;

    // Unwrap Bing News redirect links (`apiclick.aspx?...&url=https%3a%2f%2f...`)
    let resolvedLink = rawLink;
    try {
      const parsed = new URL(rawLink);
      const embedded = parsed.searchParams.get("url");
      if (embedded && embedded.startsWith("http")) {
        resolvedLink = embedded;
      }
    } catch {
      // Keep rawLink
    }

    items.push({
      title: decodeXmlEntities(titleMatch?.[1] ?? ""),
      link: resolvedLink,
      description: decodeXmlEntities(descMatch?.[1] ?? ""),
      pubDate: dateMatch ? decodeXmlEntities(dateMatch[1]) : null,
    });
  }
  return items;
}

async function fetchTextWithTimeout(
  url: string,
  timeoutMs: number,
  maxBytes = 1_250_000,
  extraHeaders: Record<string, string> = {},
): Promise<{ status: number; text: string; finalUrl: string } | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      redirect: "follow",
      headers: {
        "user-agent": BROWSER_UA,
        accept:
          "text/html,application/xhtml+xml,application/xml;q=0.9,text/plain;q=0.8,*/*;q=0.7",
        "accept-language": "en-US,en;q=0.9",
        ...extraHeaders,
      },
    });
    const status = response.status;
    if (!response.body) {
      return { status, text: "", finalUrl: response.url || url };
    }

    const reader = response.body.getReader();
    const chunks: Uint8Array[] = [];
    let total = 0;
    while (total < maxBytes) {
      const { done, value } = await reader.read();
      if (done || !value) break;
      chunks.push(value);
      total += value.byteLength;
    }
    try {
      await reader.cancel();
    } catch {
      // Ignore cancel errors
    }

    const merged = Buffer.concat(chunks.map((c) => Buffer.from(c)));
    return {
      status,
      text: merged.toString("utf8"),
      finalUrl: response.url || url,
    };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/** Optional commercial Search APIs when keys are configured in `.env`. */
async function searchConfiguredApis(query: string): Promise<CandidateUrl[]> {
  if (process.env.TAVILY_API_KEY) {
    try {
      const res = await fetch("https://api.tavily.com/search", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          api_key: process.env.TAVILY_API_KEY,
          query,
          max_results: 6,
        }),
      });
      if (res.ok) {
        const data = (await res.json()) as {
          results?: { url?: string; title?: string; content?: string }[];
        };
        return (data.results ?? [])
          .filter((item) => item.url && isSafeExternalUrl(item.url))
          .map((item, idx) => ({
            url: normalizeUrl(item.url as string),
            title: item.title,
            snippet: item.content,
            via: "search-api" as const,
            priority: 95 - idx * 3,
          }));
      }
    } catch {
      // Fall through
    }
  }

  if (process.env.BRAVE_SEARCH_API_KEY) {
    try {
      const res = await fetch(
        `https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=6`,
        {
          headers: {
            "X-Subscription-Token": process.env.BRAVE_SEARCH_API_KEY,
            accept: "application/json",
          },
        },
      );
      if (res.ok) {
        const data = (await res.json()) as {
          web?: { results?: { url?: string; title?: string; description?: string }[] };
        };
        return (data.web?.results ?? [])
          .filter((item) => item.url && isSafeExternalUrl(item.url))
          .map((item, idx) => ({
            url: normalizeUrl(item.url as string),
            title: item.title,
            snippet: item.description,
            via: "search-api" as const,
            priority: 95 - idx * 3,
          }));
      }
    } catch {
      // Fall through
    }
  }

  return [];
}

async function searchBingNews(query: string, tokens: string[]): Promise<CandidateUrl[]> {
  const url = `https://www.bing.com/news/search?q=${encodeURIComponent(query)}&setlang=en-US&format=rss`;
  const fetched = await fetchTextWithTimeout(url, 6000, 350_000);
  if (!fetched || fetched.status >= 400) return [];
  const items = parseRssItems(fetched.text);
  const out: CandidateUrl[] = [];
  for (const item of items) {
    if (!isSafeExternalUrl(item.link) || isBlockedDomain(item.link)) continue;
    const hay = `${item.title} ${item.description}`.toLowerCase();
    const hits = tokens.filter((t) => hay.includes(t)).length;
    if (tokens.length >= 2 && hits === 0) continue;
    out.push({
      url: normalizeUrl(item.link),
      title: item.title,
      snippet: item.description,
      publishedAt: item.pubDate,
      via: "news-index",
      priority: 82 + hits * 5,
    });
  }
  return out.slice(0, 6);
}

async function searchBingWeb(query: string, tokens: string[]): Promise<CandidateUrl[]> {
  const phrased = tokens.length >= 2 ? `${query} overview guide` : query;
  const url = `https://www.bing.com/search?q=${encodeURIComponent(phrased)}&setlang=en-US&format=rss`;
  const fetched = await fetchTextWithTimeout(url, 6000, 350_000);
  if (!fetched || fetched.status >= 400) return [];
  const items = parseRssItems(fetched.text);
  const out: CandidateUrl[] = [];
  for (const item of items) {
    if (!isSafeExternalUrl(item.link) || isBlockedDomain(item.link)) continue;
    const hay = `${item.title} ${item.description}`.toLowerCase();
    const hits = tokens.filter((t) => hay.includes(t)).length;
    if (tokens.length >= 2 && hits < Math.min(2, tokens.length)) continue;
    out.push({
      url: normalizeUrl(item.link),
      title: item.title,
      snippet: item.description,
      publishedAt: item.pubDate,
      via: "web-search",
      priority: 76 + hits * 6,
    });
  }
  return out.slice(0, 6);
}

async function searchWikipediaAndRefs(
  query: string,
  tokens: string[],
): Promise<{ wikiSources: ResearchSource[]; refCandidates: CandidateUrl[] }> {
  const searchUrl = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(
    query,
  )}&srlimit=2&format=json`;
  const searchRes = await fetchTextWithTimeout(searchUrl, 5500, 200_000);
  if (!searchRes || searchRes.status >= 400) {
    return { wikiSources: [], refCandidates: [] };
  }

  let titles: string[] = [];
  try {
    const parsed = JSON.parse(searchRes.text) as {
      query?: { search?: { title?: string }[] };
    };
    titles = (parsed.query?.search ?? [])
      .map((s) => s.title ?? "")
      .filter(Boolean)
      .slice(0, 2);
  } catch {
    return { wikiSources: [], refCandidates: [] };
  }

  if (titles.length === 0) {
    return { wikiSources: [], refCandidates: [] };
  }

  const detailUrl = `https://en.wikipedia.org/w/api.php?action=query&prop=extracts|extlinks|info&inprop=url&explaintext=1&exchars=5500&ellimit=12&titles=${encodeURIComponent(
    titles.join("|"),
  )}&format=json`;
  const detailRes = await fetchTextWithTimeout(detailUrl, 6000, 400_000);
  if (!detailRes || detailRes.status >= 400) {
    return { wikiSources: [], refCandidates: [] };
  }

  const wikiSources: ResearchSource[] = [];
  const refCandidates: CandidateUrl[] = [];

  try {
    const data = JSON.parse(detailRes.text) as {
      query?: {
        pages?: Record<
          string,
          {
            title?: string;
            extract?: string;
            fullurl?: string;
            extlinks?: { "*"?: string; url?: string }[];
          }
        >;
      };
    };

    for (const page of Object.values(data.query?.pages ?? {})) {
      const extract = (page.extract ?? "").trim();
      const pageUrl =
        page.fullurl ??
        `https://en.wikipedia.org/wiki/${encodeURIComponent(
          (page.title ?? "").replace(/\s+/g, "_"),
        )}`;
      if (!extract || extract.length < 140) continue;

      const headings = Array.from(extract.matchAll(/^==+\s*([^=]+?)\s*==+$/gm))
        .map((m) => m[1].trim())
        .filter(
          (h) =>
            !/^(see also|references|external links|further reading|notes|bibliography)$/i.test(
              h,
            ),
        )
        .slice(0, 6);

      const cleanProse = extract.replace(/^==+[^=]+==+$/gm, "\n");
      const facts = distillFacts(cleanProse, tokens, 6);
      if (facts.length === 0) continue;

      wikiSources.push({
        id: `src-${shortId(pageUrl)}`,
        url: pageUrl,
        domain: "en.wikipedia.org",
        title: `${page.title ?? "Wikipedia"} — Encyclopedia Entry`,
        siteName: "Wikipedia",
        via: "wikipedia",
        visited: true,
        statusCode: 200,
        wordCount: cleanProse.split(/\s+/).filter(Boolean).length,
        excerpt: facts[0],
        headings,
        facts,
      });

      for (const ext of page.extlinks ?? []) {
        const link = ext.url ?? ext["*"] ?? "";
        if (
          link.startsWith("http") &&
          isSafeExternalUrl(link) &&
          !isBlockedDomain(link) &&
          !link.includes("archive.org") &&
          !link.includes("wikidata.org") &&
          !link.endsWith(".pdf")
        ) {
          refCandidates.push({
            url: normalizeUrl(link),
            title: `${page.title} reference`,
            via: "web-search",
            priority: 68,
          });
        }
      }
    }
  } catch {
    // Ignore parse error
  }

  return { wikiSources, refCandidates: refCandidates.slice(0, 5) };
}

async function searchHackerNews(query: string, tokens: string[]): Promise<CandidateUrl[]> {
  const url = `https://hn.algolia.com/api/v1/search?query=${encodeURIComponent(
    query,
  )}&tags=story&hitsPerPage=6`;
  const res = await fetchTextWithTimeout(url, 5000, 180_000);
  if (!res || res.status >= 400) return [];
  try {
    const parsed = JSON.parse(res.text) as {
      hits?: { title?: string; url?: string; points?: number; created_at?: string }[];
    };
    const out: CandidateUrl[] = [];
    for (const hit of parsed.hits ?? []) {
      if (!hit.url || !isSafeExternalUrl(hit.url) || isBlockedDomain(hit.url)) continue;
      if (hit.url.endsWith(".pdf")) continue;
      const titleLower = (hit.title ?? "").toLowerCase();
      const hits = tokens.filter((t) => titleLower.includes(t)).length;
      if (tokens.length >= 2 && hits < Math.min(2, tokens.length)) continue;
      if ((hit.points ?? 0) < 10 && hits < 2) continue;
      out.push({
        url: normalizeUrl(hit.url),
        title: hit.title,
        publishedAt: hit.created_at ?? null,
        via: "hn-index",
        priority: 72 + hits * 5,
      });
    }
    return out.slice(0, 4);
  } catch {
    return [];
  }
}

function cleanSentenceForSpeech(raw: string): string {
  return raw
    .replace(/\[[0-9a-z,\s]+\]/gi, "")
    .replace(/\(listen\)/gi, "")
    .replace(/https?:\/\/\S+/gi, "")
    .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
    .replace(/\s+/g, " ")
    .replace(/\s+([.,;:!?])/g, "$1")
    .trim();
}

function jaccardWords(a: string, b: string): number {
  const setA = new Set(a.toLowerCase().split(/\W+/).filter((w) => w.length > 3));
  const setB = new Set(b.toLowerCase().split(/\W+/).filter((w) => w.length > 3));
  if (setA.size === 0 || setB.size === 0) return 0;
  let inter = 0;
  for (const word of setA) {
    if (setB.has(word)) inter += 1;
  }
  return inter / (setA.size + setB.size - inter);
}

/**
 * Distills clean, verifiable, spoken-ready factual sentences from extracted
 * webpage prose.
 */
export function distillFacts(
  prose: string,
  queryTokens: string[],
  maxFacts = 6,
): string[] {
  const normalized = prose
    .replace(/\r/g, "\n")
    .replace(/\n{2,}/g, "\n")
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line.length >= 40);

  const rawSentences: string[] = [];
  for (const paragraph of normalized) {
    const parts = paragraph.split(/(?<=[.!?])\s+(?=[A-Z0-9"“])/);
    for (const part of parts) {
      const cleaned = cleanSentenceForSpeech(part);
      if (cleaned.length < 48 || cleaned.length > 235) continue;
      if (!/[.!?]$/.test(cleaned)) continue;
      if ((cleaned.match(/\|/g) ?? []).length >= 2) continue;
      if (BOILERPLATE_PATTERNS.some((pat) => pat.test(cleaned))) continue;
      const alphaCount = (cleaned.match(/[a-zA-Z]/g) ?? []).length;
      if (alphaCount < cleaned.length * 0.65) continue;
      rawSentences.push(cleaned);
    }
  }

  const scored = rawSentences.map((sentence, idx) => {
    const lower = sentence.toLowerCase();
    let score = 0;
    for (const token of queryTokens) {
      if (lower.includes(token)) score += 4;
    }
    // Concrete data points (percentages, years, measurements, figures)
    if (/\b\d+(?:\.\d+)?%/.test(sentence)) score += 4;
    if (/\b(?:19|20)\d{2}\b/.test(sentence)) score += 2.5;
    if (/[$€£]\s?\d+|\b\d+\s?(?:million|billion|thousand|km|kg|gw|mw|kwh|hours|minutes|seconds|countries|percent)\b/i.test(sentence)) {
      score += 3.5;
    }
    const hasTopicHit =
      queryTokens.length === 0 || queryTokens.some((token) => lower.includes(token));
    // Slight preference for lead/early article paragraphs
    if (idx < 6) score += 2.5 - idx * 0.35;
    return { sentence, score, hasTopicHit };
  });

  scored.sort((a, b) => b.score - a.score);

  const selected: string[] = [];
  for (const item of scored) {
    if (selected.length >= maxFacts) break;
    if (queryTokens.length >= 2 && !item.hasTopicHit && selected.length >= 1) {
      continue;
    }
    if (selected.some((existing) => jaccardWords(existing, item.sentence) > 0.52)) {
      continue;
    }
    selected.push(item.sentence);
  }
  return selected;
}

/**
 * Visits a single external website, parses the HTML DOM with Mozilla
 * Readability + OpenGraph/JSON-LD fallbacks + Jina Reader fallback for JS SPAs,
 * and extracts clean prose, headings, and spoken-ready facts.
 */
async function extractDirectWikipediaPage(
  rawUrl: string,
  via: ResearchVia,
  queryTokens: string[],
): Promise<ResearchSource | null> {
  try {
    const parsed = new URL(rawUrl);
    const match = /^([a-z]{2,3})\.wikipedia\.org$/i.exec(parsed.hostname);
    if (!match || !parsed.pathname.startsWith("/wiki/")) return null;
    const lang = match[1].toLowerCase();
    const pageSlug = decodeURIComponent(parsed.pathname.slice("/wiki/".length));
    if (!pageSlug || pageSlug.includes(":")) return null;

    const apiUrl = `https://${lang}.wikipedia.org/w/api.php?action=query&prop=extracts|info&inprop=url&explaintext=1&exchars=6500&titles=${encodeURIComponent(
      pageSlug,
    )}&format=json`;
    const res = await fetchTextWithTimeout(apiUrl, 5500, 350_000);
    if (!res || res.status >= 400) return null;
    const json = JSON.parse(res.text) as {
      query?: {
        pages?: Record<
          string,
          { title?: string; extract?: string; fullurl?: string }
        >;
      };
    };
    const page = Object.values(json.query?.pages ?? {})[0];
    const extract = (page?.extract ?? "").trim();
    if (!extract || extract.length < 120) return null;

    const headings = Array.from(extract.matchAll(/^==+\s*([^=]+?)\s*==+$/gm))
      .map((m) => m[1].trim())
      .filter(
        (h) =>
          !/^(see also|references|external links|further reading|notes|bibliography)$/i.test(
            h,
          ),
      )
      .slice(0, 6);
    const cleanProse = extract.replace(/^==+[^=]+==+$/gm, "\n");
    const facts = distillFacts(cleanProse, queryTokens, 6);
    if (facts.length === 0) return null;
    const finalUrl = page?.fullurl ?? rawUrl;

    return {
      id: `src-${shortId(finalUrl)}`,
      url: finalUrl,
      domain: `${lang}.wikipedia.org`,
      title: page?.title ?? pageSlug.replace(/_/g, " "),
      siteName: "Wikipedia",
      via,
      visited: true,
      statusCode: 200,
      wordCount: cleanProse.split(/\s+/).filter(Boolean).length,
      excerpt: facts[0],
      headings,
      facts,
    };
  } catch {
    return null;
  }
}

export async function visitAndExtractWebsite(
  candidate: CandidateUrl,
  queryTokens: string[],
): Promise<ResearchSource | null> {
  if (!isSafeExternalUrl(candidate.url)) return null;

  if (/\.wikipedia\.org\/wiki\//i.test(candidate.url)) {
    const wikiDirect = await extractDirectWikipediaPage(
      candidate.url,
      candidate.via,
      queryTokens,
    );
    if (wikiDirect) return wikiDirect;
  }

  const fetched = await fetchTextWithTimeout(candidate.url, 7200, 1_100_000);
  let statusCode = fetched?.status ?? null;
  let finalUrl = fetched?.finalUrl || candidate.url;
  if (!isSafeExternalUrl(finalUrl)) finalUrl = candidate.url;
  const domain = getDomain(finalUrl) || getDomain(candidate.url);

  let title = candidate.title?.trim() ?? "";
  let siteName = domain;
  let publishedAt = candidate.publishedAt ?? null;
  const headings: string[] = [];
  const paragraphs: string[] = [];

  if (fetched && fetched.status >= 200 && fetched.status < 400 && fetched.text.length > 80) {
    try {
      const { document } = parseHTML(fetched.text);

      const ogTitle =
        document.querySelector('meta[property="og:title"]')?.getAttribute("content") ??
        document.querySelector('meta[name="twitter:title"]')?.getAttribute("content") ??
        document.querySelector("title")?.textContent ??
        "";
      const ogDesc =
        document.querySelector('meta[property="og:description"]')?.getAttribute("content") ??
        document.querySelector('meta[name="description"]')?.getAttribute("content") ??
        "";
      const ogSite =
        document.querySelector('meta[property="og:site_name"]')?.getAttribute("content") ?? "";
      const ogPub =
        document
          .querySelector('meta[property="article:published_time"]')
          ?.getAttribute("content") ?? null;

      if (ogTitle.trim() && !BOT_CHALLENGE_TITLE_RE.test(ogTitle.trim())) {
        title = ogTitle.trim();
      }
      if (BOT_CHALLENGE_TITLE_RE.test(ogTitle.trim())) {
        throw new Error("Bot challenge page");
      }
      if (ogSite.trim()) siteName = ogSite.trim();
      if (ogPub) publishedAt = ogPub;

      for (const h of Array.from(
        document.querySelectorAll("article h2, article h3, main h2, main h3"),
      ).slice(0, 12)) {
        const text = (h.textContent ?? "").replace(/\s+/g, " ").trim();
        if (
          text.length >= 6 &&
          text.length <= 72 &&
          !CHROME_HEADING_RE.test(text) &&
          !headings.includes(text)
        ) {
          headings.push(text);
        }
      }

      // Extract JSON-LD articleBody/description if present
      for (const scriptEl of Array.from(
        document.querySelectorAll('script[type="application/ld+json"]'),
      ).slice(0, 4)) {
        try {
          const json = JSON.parse(scriptEl.textContent ?? "{}");
          const nodes = Array.isArray(json) ? json : [json];
          for (const node of nodes) {
            if (typeof node?.articleBody === "string" && node.articleBody.length > 80) {
              paragraphs.push(node.articleBody);
            } else if (typeof node?.description === "string" && node.description.length > 60) {
              paragraphs.push(node.description);
            }
          }
        } catch {
          // Ignore malformed JSON-LD
        }
      }

      // Run Mozilla Readability on the parsed DOM
      const reader = new Readability(document as unknown as Document);
      const article = reader.parse();
      if (article) {
        if (article.title?.trim()) title = article.title.trim();
        if (article.siteName?.trim()) siteName = article.siteName.trim();
        if (article.content) {
          const { document: contentDoc } = parseHTML(`<div>${article.content}</div>`);
          for (const block of Array.from(
            contentDoc.querySelectorAll("p, li, blockquote"),
          )) {
            const txt = (block.textContent ?? "").replace(/\s+/g, " ").trim();
            if (txt.length >= 45) paragraphs.push(txt);
          }
        }
        if (paragraphs.length === 0 && article.textContent) {
          paragraphs.push(article.textContent.replace(/\s+/g, " ").trim());
        }
      }

      // Fallback to raw <article>/<main> paragraphs on landing/product pages
      if (paragraphs.join(" ").length < 220) {
        for (const p of Array.from(
          document.querySelectorAll("article p, main p, section p, p"),
        ).slice(0, 30)) {
          const txt = (p.textContent ?? "").replace(/\s+/g, " ").trim();
          if (txt.length >= 48) paragraphs.push(txt);
        }
      }

      if (ogDesc.trim().length >= 50) {
        paragraphs.unshift(ogDesc.trim());
      }
    } catch {
      // Fall through to Jina reader check
    }
  }

  // Fallback for JS-rendered SPAs or 403 anti-bot challenges: reader proxy
  if (paragraphs.join(" ").length < 180) {
    const readerUrl = `https://r.jina.ai/${candidate.url}`;
    const proxied = await fetchTextWithTimeout(readerUrl, 6800, 450_000, {
      "x-no-cache": "true",
    });
    if (proxied && proxied.status >= 200 && proxied.status < 400 && proxied.text.length > 180) {
      statusCode = statusCode && statusCode < 400 ? statusCode : 200;
      const lines = proxied.text.split("\n");
      for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith("Title:") && !title) {
          title = trimmed.replace(/^Title:\s*/i, "").trim();
          continue;
        }
        const hMatch = /^#{1,3}\s+(.+)$/.exec(trimmed);
        if (hMatch) {
          const hText = hMatch[1].replace(/\[([^\]]+)\]\([^)]+\)/g, "$1").trim();
          if (
            hText.length >= 6 &&
            hText.length <= 72 &&
            !CHROME_HEADING_RE.test(hText) &&
            headings.length < 8
          ) {
            headings.push(hText);
          }
          continue;
        }
        if (
          trimmed.length >= 55 &&
          !trimmed.startsWith("URL Source:") &&
          !trimmed.startsWith("Markdown Content:") &&
          !trimmed.startsWith("![")
        ) {
          paragraphs.push(trimmed.replace(/\[([^\]]+)\]\([^)]+\)/g, "$1"));
        }
      }
    }
  }

  if (candidate.snippet && candidate.snippet.length >= 50) {
    paragraphs.push(candidate.snippet);
  }

  const combinedProse = paragraphs.join("\n\n");
  const wordCount = combinedProse.split(/\s+/).filter(Boolean).length;
  const facts = distillFacts(combinedProse, queryTokens, 6);

  if (facts.length === 0 && (!candidate.snippet || candidate.snippet.length < 45)) {
    return null;
  }

  const fallbackFact = candidate.snippet
    ? cleanSentenceForSpeech(
        /[.!?]$/.test(candidate.snippet.trim())
          ? candidate.snippet.trim()
          : `${candidate.snippet.trim()}.`,
      )
    : "";

  if (BOT_CHALLENGE_TITLE_RE.test(title.trim())) {
    return null;
  }

  const finalFacts = facts.length > 0 ? facts : fallbackFact ? [fallbackFact] : [];
  if (finalFacts.length === 0) return null;

  return {
    id: `src-${shortId(finalUrl)}`,
    url: finalUrl,
    domain,
    title: (title || domain).slice(0, 140),
    siteName: (siteName || domain).slice(0, 60),
    via: candidate.via,
    visited: Boolean(statusCode && statusCode >= 200 && statusCode < 400 && wordCount >= 40),
    statusCode,
    wordCount,
    excerpt: finalFacts[0],
    headings: headings.slice(0, 6),
    facts: finalFacts,
    publishedAt,
  };
}

export type ResearchTopicOptions = {
  prompt: string;
  urls?: string[];
  maxSources?: number;
};

/**
 * End-to-end Web Research & Website Content Extraction pipeline:
 * 1. Harvests any direct URLs from the prompt or `urls` array and visits them first.
 * 2. Searches live web, news, Wikipedia, and technical story indexes in parallel.
 * 3. Visits top diverse websites, extracts clean article text & headings, and
 *    distills spoken-ready factual claims with source citations.
 */
export async function researchTopic(
  options: ResearchTopicOptions,
): Promise<ResearchDossier> {
  const crawlLog: ResearchLogEntry[] = [];
  const t0 = Date.now();

  const embeddedUrls = extractUrlsFromText(options.prompt);
  const extraUrls = (options.urls ?? [])
    .flatMap((entry) => extractUrlsFromText(entry.startsWith("http") ? entry : `https://${entry}`))
    .filter((url) => isSafeExternalUrl(url));

  const seedUrls = Array.from(new Set([...embeddedUrls, ...extraUrls])).slice(0, 5);
  const maxSources = Math.min(7, Math.max(3, options.maxSources ?? 5));

  let query = stripUrlsAndFraming(options.prompt);
  let queryTokens = tokenizeQuery(query);

  const visitedSeedSources: ResearchSource[] = [];
  if (seedUrls.length > 0) {
    const seedStart = Date.now();
    const seedResults = await Promise.all(
      seedUrls.map((url, idx) =>
        visitAndExtractWebsite(
          { url, via: "direct-url", priority: 120 - idx },
          queryTokens,
        ),
      ),
    );
    for (const src of seedResults) {
      if (src) visitedSeedSources.push(src);
    }
    crawlLog.push({
      step: "seed-urls",
      detail: `Visited ${seedUrls.length} direct URL(s) · extracted ${visitedSeedSources.reduce(
        (acc, s) => acc + s.wordCount,
        0,
      )} words`,
      ms: Date.now() - seedStart,
    });

    // If the user only pasted a URL without a topic description, derive the
    // research topic directly from the extracted page title!
    if (!query && visitedSeedSources[0]?.title) {
      query = visitedSeedSources[0].title
        .split(/\s+[|\-—–:]\s+/)[0]
        .trim();
      queryTokens = tokenizeQuery(query);
    }
  }

  if (!query) {
    query = options.prompt.trim().slice(0, 120);
    queryTokens = tokenizeQuery(query);
  }

  let wikiSources: ResearchSource[] = [];
  const candidatePool: CandidateUrl[] = [];

  // Run multi-index web discovery unless seed URLs already filled the quota
  if (visitedSeedSources.length < maxSources && query.length >= 2) {
    const searchStart = Date.now();
    const [apiHits, newsHits, webHits, wikiBundle, hnHits] = await Promise.all([
      searchConfiguredApis(query),
      searchBingNews(query, queryTokens),
      searchBingWeb(query, queryTokens),
      searchWikipediaAndRefs(query, queryTokens),
      searchHackerNews(query, queryTokens),
    ]);

    wikiSources = wikiBundle.wikiSources;
    candidatePool.push(
      ...apiHits,
      ...newsHits,
      ...webHits,
      ...hnHits,
      ...wikiBundle.refCandidates,
    );

    crawlLog.push({
      step: "web-discovery",
      detail: `Queried web, news, Wikipedia & story indexes for "${query}" (${
        candidatePool.length + wikiSources.length
      } candidates)`,
      ms: Date.now() - searchStart,
    });
  }

  // Deduplicate candidates and diversify domains so we don't crawl the same host 4 times
  candidatePool.sort((a, b) => b.priority - a.priority);
  const seenUrls = new Set<string>([
    ...seedUrls.map(normalizeUrl),
    ...visitedSeedSources.map((s) => normalizeUrl(s.url)),
    ...wikiSources.map((s) => normalizeUrl(s.url)),
  ]);
  const domainCounts = new Map<string, number>();
  for (const s of [...visitedSeedSources, ...wikiSources]) {
    domainCounts.set(s.domain, (domainCounts.get(s.domain) ?? 0) + 1);
  }

  const remainingSlots = Math.max(
    0,
    maxSources - visitedSeedSources.length - Math.min(1, wikiSources.length),
  );
  const targetsToVisit: CandidateUrl[] = [];

  for (const cand of candidatePool) {
    if (targetsToVisit.length >= remainingSlots + 2) break;
    const norm = normalizeUrl(cand.url);
    if (seenUrls.has(norm)) continue;
    const dom = getDomain(norm);
    if (!dom || (domainCounts.get(dom) ?? 0) >= 2) continue;
    seenUrls.add(norm);
    domainCounts.set(dom, (domainCounts.get(dom) ?? 0) + 1);
    targetsToVisit.push(cand);
  }

  const crawledWebSources: ResearchSource[] = [];
  if (targetsToVisit.length > 0) {
    const crawlStart = Date.now();
    const crawled = await Promise.all(
      targetsToVisit.map((target) => visitAndExtractWebsite(target, queryTokens)),
    );
    for (const item of crawled) {
      if (item) crawledWebSources.push(item);
    }
    crawlLog.push({
      step: "site-extraction",
      detail: `Visited ${targetsToVisit.length} external site(s) · extracted ${crawledWebSources.length} readable page(s)`,
      ms: Date.now() - crawlStart,
    });
  }

  // Assemble ordered source dossier: direct seed URLs -> crawled external websites -> Wikipedia context
  const allSources: ResearchSource[] = [
    ...visitedSeedSources,
    ...crawledWebSources,
    ...wikiSources,
  ].slice(0, maxSources);

  // Build deduplicated cross-source key facts pool
  const keyFacts: ResearchFact[] = [];
  const maxFactsTotal = 16;
  for (let pass = 0; pass < 5 && keyFacts.length < maxFactsTotal; pass += 1) {
    for (const src of allSources) {
      const factText = src.facts[pass];
      if (!factText) continue;
      if (keyFacts.some((existing) => jaccardWords(existing.text, factText) > 0.5)) {
        continue;
      }
      keyFacts.push({
        text: factText,
        sourceId: src.id,
        domain: src.domain,
        title: src.title,
        url: src.url,
      });
      if (keyFacts.length >= maxFactsTotal) break;
    }
  }

  crawlLog.push({
    step: "complete",
    detail: `Compiled ${keyFacts.length} grounded facts across ${allSources.length} source(s) in ${
      Date.now() - t0
    }ms`,
    ms: Date.now() - t0,
  });

  return {
    enabled: true,
    query,
    researchedAt: new Date().toISOString(),
    seedUrls,
    sources: allSources,
    keyFacts,
    crawlLog,
  };
}

/**
 * Merges a newly visited URL or sub-topic research run into an existing
 * project's Research Dossier without losing previously collected sources.
 */
export function mergeResearchDossiers(
  existing: ResearchDossier,
  incoming: ResearchDossier,
): ResearchDossier {
  const seenUrls = new Set<string>();
  const mergedSources: ResearchSource[] = [];

  for (const src of [...incoming.sources, ...(existing.sources ?? [])]) {
    const key = normalizeUrl(src.url);
    if (seenUrls.has(key)) continue;
    seenUrls.add(key);
    mergedSources.push(src);
  }

  const mergedFacts: ResearchFact[] = [];
  for (const fact of [...incoming.keyFacts, ...(existing.keyFacts ?? [])]) {
    if (mergedFacts.some((f) => jaccardWords(f.text, fact.text) > 0.52)) continue;
    mergedFacts.push(fact);
    if (mergedFacts.length >= 20) break;
  }

  return {
    enabled: true,
    query: incoming.query || existing.query,
    researchedAt: incoming.researchedAt ?? new Date().toISOString(),
    seedUrls: Array.from(
      new Set([...(existing.seedUrls ?? []), ...(incoming.seedUrls ?? [])]),
    ),
    sources: mergedSources.slice(0, 10),
    keyFacts: mergedFacts,
    crawlLog: [...incoming.crawlLog, ...(existing.crawlLog ?? [])].slice(0, 12),
  };
}
