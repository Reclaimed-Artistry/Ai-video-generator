import { NextResponse } from "next/server";
import { researchTopic } from "@/lib/research";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as {
    prompt?: string;
    query?: string;
    urls?: string[];
    maxSources?: number;
  };

  const prompt = (body.prompt ?? body.query ?? "").trim();
  const urls = Array.isArray(body.urls)
    ? body.urls.map((u) => String(u).trim()).filter(Boolean)
    : [];

  if (!prompt && urls.length === 0) {
    return NextResponse.json(
      { error: "Provide a topic or at least one website URL to visit" },
      { status: 400 },
    );
  }

  const dossier = await researchTopic({
    prompt: prompt || urls.join(" "),
    urls,
    maxSources: body.maxSources ?? 5,
  });

  return NextResponse.json({ dossier });
}
