import { NextResponse } from "next/server";
import { db } from "@/db";
import { projects } from "@/db/schema";
import { listProjects, toProject } from "@/lib/projects";
import { researchTopic } from "@/lib/research";
import { generateScript } from "@/lib/script";
import {
  EMPTY_RESEARCH_DOSSIER,
  type AspectRatio,
  type ResearchDossier,
  type Resolution,
  type Style,
  type Tone,
} from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const items = await listProjects(24);
  return NextResponse.json({ projects: items });
}

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as {
    prompt?: string;
    title?: string;
    duration?: number;
    tone?: Tone;
    style?: Style;
    resolution?: Resolution;
    aspect?: AspectRatio;
    voice?: string;
    language?: string;
    researchMode?: boolean;
    sourceUrls?: string[];
    preloadedDossier?: ResearchDossier | null;
  };

  const sourceUrls = Array.isArray(body.sourceUrls)
    ? body.sourceUrls.map((u) => String(u).trim()).filter(Boolean)
    : [];
  const prompt = (body.prompt ?? "").trim() || sourceUrls.join(" ");

  if (!prompt) {
    return NextResponse.json(
      { error: "Enter a production brief or paste a website URL" },
      { status: 400 },
    );
  }

  const duration = Math.min(90, Math.max(15, Number(body.duration ?? 30)));
  const tone = (body.tone ?? "cinematic") as Tone;
  const shouldResearch = body.researchMode !== false || sourceUrls.length > 0;

  let dossier: ResearchDossier = EMPTY_RESEARCH_DOSSIER;
  if (
    body.preloadedDossier &&
    Array.isArray(body.preloadedDossier.sources) &&
    body.preloadedDossier.sources.length > 0
  ) {
    dossier = body.preloadedDossier;
  } else if (shouldResearch) {
    try {
      dossier = await researchTopic({
        prompt,
        urls: sourceUrls,
        maxSources: 5,
      });
    } catch {
      dossier = EMPTY_RESEARCH_DOSSIER;
    }
  }

  const script = await generateScript({
    prompt,
    duration,
    tone,
    language: body.language ?? "en",
    dossier: dossier.sources.length > 0 ? dossier : null,
  });

  const stageLabel =
    dossier.sources.length > 0
      ? `Script grounded in ${dossier.sources.length} web source(s)`
      : "Script ready";

  const inserted = await db
    .insert(projects)
    .values({
      title: body.title?.trim() || script.title,
      prompt,
      status: "ready",
      progress: 0,
      stage: stageLabel,
      tone,
      style: (body.style ?? "modern") as Style,
      resolution: (body.resolution ?? "1080p") as Resolution,
      aspect: (body.aspect ?? "16:9") as AspectRatio,
      voice: body.voice ?? "ava",
      language: body.language ?? "en",
      duration,
      script,
      research: dossier,
    })
    .returning();

  return NextResponse.json({ project: toProject(inserted[0]) }, { status: 201 });
}
