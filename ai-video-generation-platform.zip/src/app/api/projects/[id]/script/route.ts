import { NextResponse } from "next/server";
import { getProject, updateProject } from "@/lib/projects";
import { researchTopic } from "@/lib/research";
import { generateScript } from "@/lib/script";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Context = { params: Promise<{ id: string }> };

export async function POST(request: Request, context: Context) {
  const { id } = await context.params;
  const project = await getProject(id);
  if (!project) {
    return NextResponse.json({ error: "Project not found" }, { status: 404 });
  }

  const body = (await request.json().catch(() => ({}))) as {
    refreshResearch?: boolean;
  };

  let dossier = project.research;
  if (body.refreshResearch || (!dossier.sources?.length && dossier.enabled !== false)) {
    try {
      dossier = await researchTopic({
        prompt: project.prompt,
        urls: dossier.seedUrls,
        maxSources: 5,
      });
    } catch {
      // Keep existing dossier if network crawl fails
    }
  }

  const script = await generateScript({
    prompt: project.prompt,
    duration: project.duration,
    tone: project.tone,
    language: project.language,
    dossier: dossier.sources?.length ? dossier : null,
  });

  await updateProject(id, {
    script,
    research: dossier,
    title: script.title,
    status: "ready",
    stage: dossier.sources?.length
      ? `Script redrafted from ${dossier.sources.length} web source(s)`
      : "Script rewritten",
    progress: 0,
  });

  const updated = await getProject(id);
  return NextResponse.json({ project: updated });
}
