import { NextResponse } from "next/server";
import { getProject, updateProject } from "@/lib/projects";
import { mergeResearchDossiers, researchTopic } from "@/lib/research";
import { generateScript } from "@/lib/script";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Context = { params: Promise<{ id: string }> };

export async function POST(request: Request, context: Context) {
  const { id } = await context.params;
  const project = await getProject(id);
  if (!project) {
    return NextResponse.json({ error: "Project not found" }, { status: 404 });
  }

  const body = (await request.json().catch(() => ({}))) as {
    query?: string;
    urls?: string[];
    addUrl?: string;
    replace?: boolean;
    rebuildScript?: boolean;
  };

  const urls = [
    ...(Array.isArray(body.urls) ? body.urls : []),
    ...(body.addUrl ? [body.addUrl] : []),
  ]
    .map((u) => String(u).trim())
    .filter(Boolean);

  const queryPrompt = (body.query ?? "").trim() || (urls.length > 0 ? "" : project.prompt);

  const freshDossier = await researchTopic({
    prompt: queryPrompt || urls.join(" "),
    urls,
    maxSources: urls.length > 0 && !body.query ? Math.max(3, urls.length) : 5,
  });

  const merged = body.replace
    ? freshDossier
    : mergeResearchDossiers(project.research, freshDossier);

  let nextScript = project.script;
  let nextTitle = project.title;

  if (body.rebuildScript) {
    nextScript = await generateScript({
      prompt: project.prompt,
      duration: project.duration,
      tone: project.tone,
      language: project.language,
      dossier: merged,
    });
    nextTitle = nextScript.title;
  }

  await updateProject(id, {
    research: merged,
    ...(body.rebuildScript
      ? {
          script: nextScript,
          title: nextTitle,
          status: "ready",
          stage: `Rebuilt from ${merged.sources.length} web source(s)`,
          progress: 0,
        }
      : {}),
  });

  const updated = await getProject(id);
  return NextResponse.json({ project: updated, dossier: merged });
}
